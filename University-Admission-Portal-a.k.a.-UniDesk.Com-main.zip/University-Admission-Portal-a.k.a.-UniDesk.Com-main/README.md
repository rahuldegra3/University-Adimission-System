# University-Admission-Portal-a.k.a.-UniDesk.Com
This is my first ever java project titled "University Admission Portal" a.k.a. UniDesk.Com as we call it.

The project includes use of the following components-

--> Java 18
--> Xampp
--> Mysql Server
--> Netbeans 14 IDE
--> KGradient Jar File
--> Captcha Jar File
--> Jakarta Mail Jar File
--> MySql Connector Java Jar File

It starts with the JFrame named 'loading_page' and consists of more than 10 JFrames that have different functionality with respect to various buttons
added in each JFrame. It works well with Xampp Server which allows smooth connection with Apache Server and MySql Server along with Yahoo SMTP Server.

The project took hardwork of over 1-2 month(s).
