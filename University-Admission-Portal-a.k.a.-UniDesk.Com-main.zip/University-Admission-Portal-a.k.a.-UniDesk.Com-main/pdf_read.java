/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package unidesk_login;

/**
 *
 * @author Lester Greeks
 */
public class pdf_read {
    public static void main(String[] args){
        pdf_view pdfv=new pdf_view();
        pdfv.setVisible(true);
    }
    
}
